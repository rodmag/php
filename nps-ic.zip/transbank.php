<?php
require_once './vendor/autoload.php';
use NpsSDK\Configuration;
use NpsSDK\Constants;
use NpsSDK\Sdk;
use NpsSDK\ApiException;

/*CREATE SESSION*/
Configuration::environment(Constants::SANDBOX_ENV);
Configuration::secretKey("63ICiqVFNc0ZufhSOXxinVilq1R4cyCg1UqiKLxfvvFqZwIxUDfFiM0WLQbvOlaN");
$sdk = new Sdk();

/*SET ACCOUNT*/
$psp_MerchantId='psp_test';

/*SET PARAMS*/
$params =array(
    'psp_Version'=> '2.2',
    'psp_MerchantId'=> $psp_MerchantId,
    'psp_TxSource'=> 'WEB',
    'psp_MerchTxRef'=> rand(200,10000000), // unico
    'psp_MerchOrderId'=> rand(200,10000000), // unico por intento de transaccion
    'psp_Amount'=> '10000',
    'psp_NumPayments'=> '1',
    'psp_Currency'=> '152',
    'psp_Country'=> 'CHL',
    'psp_Product'=> '127', //Solo para TRANSBANK WEBPAY
    //'psp_CardNumber'=> '4507990000000010',
    //'psp_CardExpDate'=> '1712',
    //'psp_PosDateTime'=> '2016-12-01 12:00:00'
    'psp_CustomerMail' => 'edgardo.zulian@globalcollect.com',
    'psp_PurchaseDescription' => 'Ticket COR-MEN',
    'psp_PosDateTime' => date('Y-m-d H:i:s'),
    'psp_ReturnURL' => 'http://127.0.0.1/dump.php',
    'psp_FrmLanguage' => 'es_AR'
);


try{
      //$resp = $sdk->authorize3p($params);
      //$resp = $sdk->payOnline2p($params);
      $resp = $sdk->payOnline3p($params);
      var_dump($resp);
      echo "\n<br>Resultado: ".$resp->psp_ResponseCod;
      echo "\n<br>Mensaje: ".$resp->psp_ResponseMsg;
      echo "\n<br>Redirect Url: ".$resp->psp_FrontPSP_URL;
      echo "\n<br>Redirect to WEPBAY: <a href='".$resp->psp_FrontPSP_URL."'>GO!</a>";
}catch(ApiException $e){
      echo 'Code to handle error';
      var_dump($e);
}
