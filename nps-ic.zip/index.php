<?php
require_once './vendor/autoload.php';
use NpsSDK\Configuration;
use NpsSDK\Constants;
use NpsSDK\Sdk;
use NpsSDK\ApiException;

Configuration::environment(Constants::SANDBOX_ENV);
Configuration::secretKey("63ICiqVFNc0ZufhSOXxinVilq1R4cyCg1UqiKLxfvvFqZwIxUDfFiM0WLQbvOlaN");

$sdk = new Sdk();

$params = array(
    'psp_Version'          => '2.2',
    'psp_MerchantId'       => 'aeroarg',
    'psp_TxSource'         => 'WEB',
    'psp_MerchTxRef'       => 'ORDER56666-3',
    'psp_MerchOrderId'     => 'ORDER56666',
    'psp_Amount'           => '1000',
    'psp_NumPayments'      => '1',
    'psp_Currency'         => '032',
    'psp_Country'          => 'ARG',
    'psp_Product'          => '14',
    'psp_CustomerMail'     => 'john.doe@example.com',
    'psp_CardNumber'       => '4507990000000010',
    'psp_CardExpDate'      => '1903',
    'psp_CardSecurityCode' => '306',
    'psp_SoftDescriptor'   => 'Sol Tropical E',
    'psp_PosDateTime'      => '2016-12-01 12:00:00'

);
try{
    $resp = $sdk->payOnline2p($params);
    var_dump($resp); 
}catch(ApiException $e){
    echo 'Code to handle error';
}


?>
