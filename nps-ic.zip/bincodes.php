<?php

$url_send ="https://api.bincodes.com/bin/json/f18f42ba9031351f7674085bff1dc239/515735/";

function sendApiUrl($url){
  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  $result = curl_exec($ch);
  curl_close($ch);  // Seems like good practice
  return $result;
}

echo " " . sendApiUrl($url_send);

?>
