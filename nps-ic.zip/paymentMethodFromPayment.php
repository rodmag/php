<?php
require_once './vendor/autoload.php';
use NpsSDK\Constants;
use NpsSDK\Configuration;
use NpsSDK\Sdk;
use NpsSDK\ApiException;

/*CREATE SESSION AEROARG*/
//Configuration::environment(Constants::SANDBOX_ENV);
//Configuration::secretKey("63ICiqVFNc0ZufhSOXxinVilq1R4cyCg1UqiKLxfvvFqZwIxUDfFiM0WLQbvOlaN");
/*CREATE SESSION PAPAYA*/
Configuration::environment(Constants::STAGING_ENV);
Configuration::secretKey("YbworsJjAgUnUcrNN0ZyxuSrUfCuJuDpW9dN1v6CbYx38mQVkxShssWMVgEmbRc5");
$sdk = new Sdk();
/*SET ACCOUNT*/
$psp_MerchantId='papaya_pe';

/*SET PARAMS*/
$params =array(
    'psp_Version'=> '2.2',
    'psp_MerchantId'=> $psp_MerchantId,
    'psp_TransactionId'=> '3321214',
    //'psp_PaymentMethodTag'=> 'Default Card',
    //'psp_CustomerId'=> 'ylemJCqCa2fwyJLgIvrKZggF5Ih8bRfs', //usuario ezulian
    //'psp_SetAsCustomerDefault'=> '1',
    'psp_PosDateTime' => date('Y-m-d H:i:s'),
);
try{
    $resp = $sdk->createPaymentMethodFromPayment($params);
    var_dump($resp);
}catch(ApiException $e){
    echo 'Code to handle error';
    var_dump($e);
}
/*
RESPONSE EXAMPLE:
object(stdClass)#4 (6) {
  ["psp_ResponseCod"]=>
  string(1) "2"
  ["psp_ResponseMsg"]=>
  string(22) "SOLICITUD EXITOSA - OK"
  ["psp_MerchantId"]=>
  string(7) "aeroarg"
  ["psp_PaymentMethod"]=>
  object(stdClass)#5 (6) {
    ["PaymentMethodId"]=>
    string(32) "5GPpxZjeoA1u1i48C7pzReemJ6jYZOQT"
    ["Product"]=>
    string(2) "14"
    ["CardOutputDetails"]=>
    object(stdClass)#6 (9) {
      ["ExpirationDate"]=>
      string(4) "1803"
      ["ExpirationYear"]=>
      string(4) "2018"
      ["ExpirationMonth"]=>
      string(2) "03"
      ["HolderName"]=>
      string(14) "EDGARDO ZULIAN"
      ["IIN"]=>
      string(6) "411111"
      ["Last4"]=>
      string(4) "1111"
      ["NumberLength"]=>
      string(1) "0"
      ["MaskedNumber"]=>
      string(16) "411111******1111"
      ["MaskedNumberAlternative"]=>
      string(16) "************1111"
    }
    ["FingerPrint"]=>
    string(48) "YZcjaTteXz4ugz3SH3oWAXQSw8tjQyYBhWjornDHdjMt2nLQ"
    ["CreatedAt"]=>
    string(24) "2017-06-09 15:30:57-0300"
    ["UpdatedAt"]=>
    string(24) "2017-06-09 15:30:57-0300"
  }
  ["psp_CustomerId"]=>
  string(32) "ylemJCqCa2fwyJLgIvrKZggF5Ih8bRfs"
  ["psp_PosDateTime"]=>
  string(19) "2017-06-09 15:30:54"
}

*/
