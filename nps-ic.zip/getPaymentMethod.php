<?php
require_once './vendor/autoload.php';
use NpsSDK\Constants;
use NpsSDK\Configuration;
use NpsSDK\Sdk;
use NpsSDK\ApiException;


//Configuration::environment(Constants::SANDBOX_ENV);
Configuration::environment(Constants::STAGING_ENV);
//Configuration::secretKey("LYBNhrHz6E3AVqCaasI1d1zxYV1EA7eTdnqKf5HjKIup84OhueiYefTCBUQJa2mD"); //hoypido //KE1ttCGMbQW1q1Xx9BFJ93cu7pdbHV6U

Configuration::secretKey("Ot7LubSqDDXWaiDujqtARkzB64l3q5dCylXsKyhVBE1juCdd0UnRDkaHnMJdRwoO");

$sdk = new Sdk();

/*SET ACCOUNT*/
$psp_MerchantId='traslada';
$sdk = new Sdk();

$params =array(
    'psp_Version'=> '2.2',
    'psp_MerchantId'=> $psp_MerchantId,
    'psp_PaymentMethodId'=> 'g6mlLJYpYe5hK1exY7ZQ6ZGrh14TT9bA',
    'psp_PosDateTime'=> '2017-05-12 14:14:01'
);
try{
    $resp = $sdk->retrievePaymentMethod($params);
	var_dump($resp);
}catch(ApiException $e){
    echo 'Code to handle error';
}