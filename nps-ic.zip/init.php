<html>
<head>
  <title>NPS - Gateway - v0.1</title>
</head>
<body>
  <h2>NPS - Gateway - Payment Process</h2>
  <h3>Complete Basic Data:</h3>
  <form action="" method="post">
    <h4>Transaction Def:</h4>
    <table>
        <tr>
          <td>Type:</td>
          <td> <select name="type">
                      <option value="auth">auth</option>
                      <option value="payonline">payonline</option>
                </select>
          </td>
        </tr>
        <tr>
          <td>Vault:</td>
          <td> <select name="vault">
                      <option value="no">p2p directo</option>
                      <option value="onetimetoken">p2p onetimetoken</option>
                      <option value="paymentmethodid">p2p from paymentmethodid</option>
                </select>
          </td>
        </tr>
        <tr>
          <td>Tokenize:</td>
          <td> <select name="tokenize_mode">
                      <option>none</option>
                      <option>create Token from payment</option>
                      <option>create User add payment</option>
                      <option>update User add payment</option>
              </select>
          </td>
        </tr>
    </table>
    <h4>Basic Data:</h4>
    <table>
      <tr><td>psp_MerchTxRef:</td><td><input type="text" name="psp_MerchTxRef" value="<?php echo rand(200,10000000)?>"/></td></tr>
      <tr><td>psp_MerchOrderId: </td><td><input type="text" name="psp_MerchOrderId" value="<?php echo rand(200,10000000)?>"/></td></tr>
      <tr><td>psp_Amount: </td><td><input type="text" name="psp_Amount" value="100"/></td></tr>
      <tr><td>psp_NumPayments: </td><td><input type="text" name="psp_NumPayments" value="1"/></td></tr>
      <tr><td>psp_Currency: </td><td><input type="text" name="psp_Currency" value="032"/></td></tr>
      <tr><td>psp_Country:  </td><td><input type="text" name="psp_Country" value="ARG"/></td></tr>
      <tr><td>psp_Product: </td><td><input type="text" name="psp_Product" value="14"/></td></tr>
      <tr><td>psp_CustomerMail: </td><td><input type="text" name="psp_CustomerMail" value="edgardo.zulian@globalcollect.com"/></td></tr>
      <tr><td>psp_PurchaseDescription: </td><td><input type="text" name="psp_PurchaseDescription" value="Ticket COR-MEN"/></td></tr>
    </table>
    <h4>Card Data:</h4>
    <table>
      <tr><td>holder_name:  </td><td><input type="text" name="holder_name" value="EDGARDO ZULIAN"/></td></tr>
      <tr><td>number:  </td><td><input type="text" name="number" value="4111111111111111"/></td></tr>
      <tr><td>exp_month:  </td><td><input type="text" name="exp_month" value="03"/></td></tr>
      <tr><td>exp_year:  </td><td><input type="text" name="exp_year"  value="2018"/></td></tr>
      <tr><td>security_code:  </td><td><input type="text" name="security_code" value="123"/></td></tr>
    </table>
  </form>
  <input type="submit" value="Go!"/>
</body>
</html>
