<?php
require_once './vendor/autoload.php';
use NpsSDK\Configuration;
use NpsSDK\Constants;
use NpsSDK\Sdk;
use NpsSDK\ApiException;

/*CREATE SESSION*/
Configuration::environment(Constants::SANDBOX_ENV);
Configuration::secretKey("63ICiqVFNc0ZufhSOXxinVilq1R4cyCg1UqiKLxfvvFqZwIxUDfFiM0WLQbvOlaN");
$sdk = new Sdk();

/*SET ACCOUNT*/
$psp_MerchantId='aeroarg';

/*SET PARAMS*/
$params =array(
    'psp_Version'=> '2.2',
    'psp_MerchantId'=> $psp_MerchantId,
    'psp_PosDateTime'=>  date('Y-m-d H:i:s'),
);

/*CREATE SESSION*/
try{
    $resp = $sdk->createClientSession($params);
    var_dump($resp);
    if ($resp->psp_ResponseCod=="2"){
      echo "\n<br>\n".$resp->psp_ResponseMsg."<br>\n";
      echo "Session Key-> ".$resp->psp_ClientSession;
    }
    else
      echo "\n<br>\n".$resp->psp_ResponseMsg;
}catch(ApiException $e){
    echo 'Code to handle error';
    var_dump($e);
}
?>


<html>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
<!-- SANDBOX -->
<script type="text/javascript" src="https://sandbox.nps.com.ar/sdk/v1/NPS.js"></script>

</head>
<body>
<hr>Generando OneTimeToken...<br>
OneTimeToken -> <div id="onetimetoken"></div>
<script>
var npsSuccessResponseHandler;
npsSuccessResponseHandler = function(paymentMethodToken) {
  //alert("token: "+paymentMethodToken.id);
  document.getElementById("onetimetoken").innerHTML=paymentMethodToken.id;
 };

var npsErrorResponseHandler;
npsErrorResponseHandler = function(response) {
  alert("error:"+response.message);
};

function changeLink(id,type){
    if (type=='A') //auth
     document.getElementById(id).href = "p2p_online.php?vault=onetimetoken&type=auth&token="+document.getElementById("onetimetoken").innerHTML;
    if (type=='P') //payonline
     document.getElementById(id).href = "p2p_online.php?vault=onetimetoken&type=payonline&token="+document.getElementById("onetimetoken").innerHTML;
    }

</script>
<script>
//var npsSuccessResponseHandler;
//var npsErrorResponseHandler;
NPS.setClientSession("<?=$resp->psp_ClientSession;?>"); //reemplazar por una sesion generada por el método CreateClientSession
//alert(NPS.getClientSession());
NPS.setMerchantId("<?=$psp_MerchantId;?>");
//NPS.setUseDeviceFingerprint(true);
//NPS.getUseDeviceFingerprint();
PaymentMethodTokenParams = {
      card: {
        holder_name: 'EDGARDO ZULIAN',
        number: '4111111111111111',
        exp_month: '03',
        exp_year: '2018',
        // exp_date: '1901', // you can choose exp_date over exp_year+exp_month to send expiry date in one field only
        security_code: '123',
      },
};

NPS.paymentMethodToken.create(PaymentMethodTokenParams, npsSuccessResponseHandler, npsErrorResponseHandler);
</script>
<a id="p2pLink" href="p2p_online.php?vault=onetimetoken" onclick="changeLink('p2pLink','A');">Realizar Autorización con Token</a><br>
<a id="p2pLink2" href="p2p_online.php?vault=onetimetoken" onclick="changeLink('p2pLink2','P');">Realizar Pago con Token</a>
</body>
</html>
