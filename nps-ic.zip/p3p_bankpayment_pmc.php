<?php
require_once './vendor/autoload.php';
use NpsSDK\Configuration;
use NpsSDK\Constants;
use NpsSDK\Sdk;
use NpsSDK\ApiException;

/*CREATE SESSION*/
Configuration::environment(Constants::PRODUCTION_ENV);
Configuration::secretKey("zqyHQTpFxTmIVKeFYAgw2RhqyJI6gCVd2SuRvjeqBQ8gimtHuXDwztnvC5ztGVUG");
$sdk = new Sdk();

/*SET ACCOUNT*/
$psp_MerchantId='aeroarg_web';

/*SET PARAMS*/
$params =array(
    'psp_Version'=> '2.2',
    'psp_MerchantId'=> $psp_MerchantId,
    'psp_TxSource'=> 'WEB',
    'psp_MerchTxRef'=> rand(200,10000000), // unico
    'psp_MerchOrderId'=> rand(200,10000000), // unico por intento de transaccion
    'psp_ReturnURL'=> 'http://127.0.0.1/dump.php',
    'psp_FrmLanguage'=> 'es_AR',
    'psp_ScreenDescription'=> 'GC_20170724_1',
    'psp_TicketDescription'=> 'Ticket GC20170724',
    'psp_Currency'=> '032',
    'psp_Product'=> '320',
    'psp_Country'=> 'ARG',
    'psp_Amount1'=> '1000',
    'psp_ExpDate1'=> '2017-07-26',
    //'psp_ExpMark'=> '0',
    //'psp_CustomerMail' => 'edgardo.zulian@globalcollect.com',
    //'psp_PurchaseDescription' => 'Ticket COR-MEN',
    'psp_PosDateTime' => date('Y-m-d H:i:s')
);


try{
    $resp = $sdk->bankPayment3p($params);
    //$resp = $sdk->payOnline3p($params);
    var_dump($resp);
    echo "\n<br>Resultado: ".$resp->psp_ResponseCod;
    echo "\n<br>Mensaje: ".$resp->psp_ResponseMsg;
    echo "\n<br>Mensaje Extendido: ".$resp->psp_ResponseExtended;
}catch(ApiException $e){
    echo 'Code to handle error';
    var_dump($e);
}
