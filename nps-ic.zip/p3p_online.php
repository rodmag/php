<?php
require_once './vendor/autoload.php';
use NpsSDK\Configuration;
use NpsSDK\Constants;
use NpsSDK\Sdk;
use NpsSDK\ApiException;

/*CREATE SESSION*/
Configuration::environment(Constants::SANDBOX_ENV);
Configuration::secretKey("63ICiqVFNc0ZufhSOXxinVilq1R4cyCg1UqiKLxfvvFqZwIxUDfFiM0WLQbvOlaN");
$sdk = new Sdk();

/*SET ACCOUNT*/
$psp_MerchantId='aeroarg';

/*SET PARAMS*/
$params =array(
    'psp_Version'=> '2.2',
    'psp_MerchantId'=> $psp_MerchantId,
    'psp_TxSource'=> 'WEB',
    'psp_MerchTxRef'=> rand(200,10000000), // unico
    'psp_MerchOrderId'=> rand(200,10000000), // unico por intento de transaccion
    'psp_Amount'=> '100',
    'psp_NumPayments'=> '1',
    'psp_Currency'=> '032',
    'psp_Country'=> 'ARG',
    'psp_Product'=> '5', //14VISA 5MC 1AMEX 2DINERS 8 CABAL 65 ARGENCARD 48 MAS 9 NARANJA
    //'psp_CardNumber'=> '4507990000000010',
    //'psp_CardExpDate'=> '1712',
    //'psp_PosDateTime'=> '2016-12-01 12:00:00'
    'psp_ReturnURL'=> 'http://127.0.0.1/dump.php',
    'psp_FrmLanguage'=> 'es_AR',
    'psp_CustomerMail' => 'edgardo.zulian@globalcollect.com',
    'psp_PurchaseDescription' => 'Ticket COR-MEN',
    'psp_PosDateTime' => date('Y-m-d H:i:s'),
    //no solo se puede customer id 'psp_VaultReference' => array  ('PaymentMethodToken' => '5GPpxZjeoA1u1i48C7pzReemJ6jYZOQT')
    'psp_VaultReference' => array  ('CustomerId' => 'ylemJCqCa2fwyJLgIvrKZggF5Ih8bRfs')
);


try{
    $resp = $sdk->payOnline3p($params);
    var_dump($resp);
    echo "\n<br>Resultado: ".$resp->psp_ResponseCod;
    echo "\n<br>Mensaje: ".$resp->psp_ResponseMsg;
    echo "\n<br>Mensaje Extendido: ".$resp->psp_ResponseExtended;
}catch(ApiException $e){
    echo 'Code to handle error';
    var_dump($e);
}
