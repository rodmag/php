<?php
require_once './vendor/autoload.php';

use NpsSDK\Constants;
use NpsSDK\Configuration;
use NpsSDK\Sdk;
use NpsSDK\ApiException;

/*CREATE SESSION*/
//Configuration::environment(Constants::SANDBOX_ENV);
//Configuration::secretKey("63ICiqVFNc0ZufhSOXxinVilq1R4cyCg1UqiKLxfvvFqZwIxUDfFiM0WLQbvOlaN");
Configuration::environment(Constants::PRODUCTION_ENV);
//alamaula Configuration::secretKey("K1rsXpbx0cCZUHK5VR1WMXyPeCgbHv3LkMHQ3LruI2zrsmL3zj9EBb7yb0LUJjrm");
Configuration::secretKey("hlYvaNLanVge3aX9XxbWS6QGVdP7NGP21xvaIGA5lohoMFvtCWNfcmt6PGBkWbmW");
$sdk = new Sdk();

/*SET ACCOUNT*/
//$psp_MerchantId='aeroarg';
//$psp_MerchantId='alamaula';
$psp_MerchantId='th_jetsmart_c';

/*SET PARAMS*/
$params =array(
    'psp_Version'=> '2.2',
    'psp_MerchantId'=> $psp_MerchantId,
    'psp_QueryCriteria'=> 'M',
    'psp_QueryCriteriaId'=> 'cd697010-76c5-4ffb-9ea8-903086bc94fa',
    'psp_PosDateTime' => date('Y-m-d H:i:s'),
);
try{
    $resp = $sdk->simpleQueryTx($params);
    var_dump($resp);
    echo ("<HR>".$resp->psp_Transaction->psp_ResponseCod);
    echo ("<BR>".$resp->psp_Transaction->psp_ResponseMsg);
}catch(ApiException $e){
    echo 'Code to handle error';
    var_dump($e);
}
?>
