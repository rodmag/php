<?php
require_once './vendor/autoload.php';
use NpsSDK\Configuration;
use NpsSDK\Constants;
use NpsSDK\Sdk;
use NpsSDK\ApiException;

/*CREATE SESSION*/
//Configuration::environment(Constants::SANDBOX_ENV);
Configuration::environment(Constants::STAGING_ENV);
Configuration::secretKey("LPWr8nvXJt3THPuz1H57N4pCDivltbxcu4DTqaC2UTFDFQHowte32FbAvSH30nHY");
$sdk = new Sdk();

/*set GET values*/
$sVault= $_GET['vault'];//onetimetoken
$sType= $_GET['type'];//auth - payonline
$sToken = 'nkm8f9obl7vAnn4mDezKZ6QswMRus8Qd';//$_GET['token'];
echo "PARAMS-> vault: ".$sVault." -type: ".$sType." -token: ".$sToken."<BR>\n";

/*SET ACCOUNT*/
$psp_MerchantId='pedidosya';

/*SET PARAMS*/
$params =array(
    'psp_Version'=> '2.2',
    'psp_MerchantId'=> $psp_MerchantId,
    'psp_TxSource'=> 'WEB',
    'psp_MerchTxRef'=> rand(200,10000000), // unico
    'psp_MerchOrderId'=> rand(200,10000000), // unico por intento de transaccion
    'psp_Amount'=> '7000',
    'psp_NumPayments'=> '1',
    'psp_Currency'=> '032', //032 ARS  604 SOLES
    'psp_Country'=> 'ARG', //ARG CHL PER
    'psp_Product'=> '14', //14VISA 5MC 1AMEX 2DINERS 8 CABAL 65 ARGENCARD 48 MAS 9 NARANJA
    'psp_CardNumber'=> '4111111111111111',
    'psp_CardExpDate'=> '2012',
    'psp_CardSecurityCode' => '123',
    'psp_PosDateTime'=> '2018-01-05 09:20:00',
    'psp_CustomerMail' => 'edgardo.zulian@globalcollect.com',
    'psp_PurchaseDescription' => 'Pedidosy Ya',
    'psp_PosDateTime' => date('Y-m-d H:i:s'),
    //'psp_VaultReference' => array  ('PaymentMethodToken' => $sToken) //one time token
    //'psp_VaultReference' => array  ('PaymentMethodId' => $sToken)  //token persistente papaya: nkm8f9obl7vAnn4mDezKZ6QswMRus8Qd
);


try{
    if(strtolower($sType)=='auth'){
    /*AUTHORIZE 2p*/
      $resp = $sdk->authorize2p($params);
    }
    else{
    /*PAYONLINE 2p*/
      $resp = $sdk->payOnline2p($params);
    }
    var_dump($resp);
    echo "\n<br>Resultado: ".$resp->psp_ResponseCod;
    echo "\n<br>Mensaje: ".$resp->psp_ResponseMsg;
    echo "\n<br>Mensaje Extendido: ".$resp->psp_ResponseExtended;
}catch(ApiException $e){
    echo 'Code to handle error';
    var_dump($e);
}
