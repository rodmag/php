<?php

require_once __DIR__ .'/vendor/autoload.php';

$communicatorConfiguration =
//new CommunicatorConfiguration('9628f327c18d7aff', 'Q7b0sazdTzqJGSjG/EG2Ahfp4LHrcvXyDWjBGnqQaM0=', 'https://api-sandbox.globalcollect.com', 'Sandbox');

//new CommunicatorConfiguration('291fc552d7e5eef3', 'o3eW+QcbUtK5hTsJZEea5EJaBvDhwcRUorBJnCUuz00=', 'https://eu.preprod.api-ingenico.com', 'Preprod');
new CommunicatorConfiguration('06287e45ab2d16cf', 'o3eW+8XpQDeSGcLXBNqIDPGzTf2Zxg3m5X8TWdrG0L2SAyb4=', 'https://api-preprod.globalcollect.com', 'Preprod');
$connection = new DefaultConnection();
$communicator = new Communicator($connection, $communicatorConfiguration);

$client = new Client($communicator);
$body = new SessionRequest();

//$response = $client->merchant("1208")->sessions()->create($body);

$response = $client->merchant("4330")->sessions()->create($body);
//$response = $client->merchant("1297")->services()->testconnection();
var_dump($response);

/*
<Parameter key = "urlTokenCC" value = "https://eu.preprod.api-ingenico.com/v1/1297/tokens"/>
<Parameter key = "key" value = "291fc552d7e5eef3"/>
<Parameter key = "privateKey" value = "o3eW+QcbUtK5hTsJZEea5EJaBvDhwcRUorBJnCUuz00="/>
estas son las de pre
*/
?>
