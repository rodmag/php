<?php
require_once './vendor/autoload.php';
use NpsSDK\Configuration;
use NpsSDK\Constants;
use NpsSDK\Sdk;
use NpsSDK\ApiException;

/*CREATE SESSION*/
//Configuration::environment(Constants::SANDBOX_ENV);
Configuration::environment(Constants::PRODUCTION_ENV);
Configuration::secretKey("2qlTfQQwBISPFxFRQtZTLXD8O2TLUcmXTY06wP37fVUuQiJpbtIuOT2nWV6y6sVX");
$sdk = new Sdk();

/*SET ACCOUNT*/
$psp_MerchantId='gc_olx';


$params =array(
    'psp_Version'=> '2.2',
    'psp_MerchantId'=> $psp_MerchantId,
    'psp_TxSource'=> 'WEB',
    'psp_MerchTxRef'=> 'TEST-PSP.595E950ABDBE90.12569165-3',
    'psp_TransactionId_Orig'=> '81220346',
    'psp_AmountToCapture'=> '1050',
    'psp_PosDateTime' => date('Y-m-d H:i:s')
);
try{
    $resp = $sdk->capture($params);
    var_dump ($resp);
}catch(ApiException $e){
    echo 'Code to handle error';
    var_dump ($e);
}
