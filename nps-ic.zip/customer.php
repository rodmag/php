<?php

/*
CUSTOMER ID: ylemJCqCa2fwyJLgIvrKZggF5Ih8bRfs
*/

require_once './vendor/autoload.php';
use NpsSDK\Constants;
use NpsSDK\Configuration;
use NpsSDK\Sdk;
use NpsSDK\ApiException;

Configuration::environment(Constants::SANDBOX_ENV);
Configuration::secretKey("63ICiqVFNc0ZufhSOXxinVilq1R4cyCg1UqiKLxfvvFqZwIxUDfFiM0WLQbvOlaN");
$sdk = new Sdk();

/*SET ACCOUNT*/
$psp_MerchantId='aeroarg';

/*SET PARAMS*/
$params =array(
    'psp_Version'=> '2.2',
    'psp_MerchantId'=> $psp_MerchantId,
    'psp_EmailAddress'=> 'edgardo.zulian@epay.ingenico.com',
    //'psp_AlternativeEmailAddress'=> 'jdoe@example.com',
    'psp_AccountID'=> 'ezulian',
    'psp_AccountCreatedAt'=> '2017-06-09',
    'psp_Person'=>array(
        'FirstName'=> 'Edgardo|',
        'LastName'=> 'Zulian',
        //'MiddleName'=> 'Michael',
        //'PhoneNumber1'=> '+1 011 11111111',
        //'PhoneNumber2'=> '+1 011 22222222',
        //'DateOfBirth'=> '1979-01-12',
        //'Gender'=> 'M',
        'Nationality'=> 'ARG',
        'IDNumber'=> '26122692',
        'IDType'=> '200' //DNI
    ),
  /*  'psp_Address'=>array(
        'Street'=> 'Av. Collins',
        'HouseNumber'=> '1245',
        'AdditionalInfo'=> '2 A',
        'StateProvince'=> 'Florida',
        'City'=> 'Miami',
        'Country'=> 'USA',
        'ZipCode'=> '33140'
    ),*/
    'psp_PosDateTime' => date('Y-m-d H:i:s'),
);
try{
    $resp = $sdk->createCustomer($params);
    var_dump($resp);
}catch(ApiException $e){
    echo 'Code to handle error';
    var_dump($e);
}
